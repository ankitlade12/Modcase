import { Hono } from 'hono';
import { createServer, context } from '@devvit/web/server';
import { redis } from '@devvit/redis';
import type { MenuItemRequest, TriggerResponse, UiResponse } from '@devvit/web/shared';

/**
 * ModCase logger-first Devvit Web starter.
 *
 * Purpose:
 * 1. Log real onModAction payloads during Day 1 so you can verify actor/target/reason fields.
 * 2. Capture only human remove/approve decisions for posts/comments.
 * 3. Let a moderator pick the reason before lookup, then show descriptive precedent.
 * 4. Compute counts from indexed records, not incremented counters, so trigger retries do not skew stats.
 *
 * Important before submission:
 * - Set CAPTURE_RAW_PAYLOADS_FOR_DEBUG to false or remove raw-payload storage.
 * - Confirm the actual ModAction payload fields from logs and tighten extract* helpers.
 * - Confirm zRange rank ordering in your playtest logs.
 */

const app = new Hono();

const APP_ACCOUNT_NAMES = new Set(['modcase', 'modcaseapp', 'modcase-bot']);
const CAPTURE_RAW_PAYLOADS_FOR_DEBUG = true; // Turn OFF before hackathon submission.
const LOOKUP_LIMIT = 50; // Signal is intentionally computed over the most recent 50 matching decisions.
const DISPLAY_LIMIT = 3;
const MIN_SIGNAL_SAMPLE = 5;
const LOOKUP_CONTEXT_TTL_SECONDS = 10 * 60;
const DEMO_SEED_PREFIX = 'demo';

type TargetType = 'post' | 'comment';
type DecisionAction = 'removed' | 'approved';

type SignalKind = 'limited_history' | 'settled' | 'leaning' | 'contested';

type DecisionRecord = {
  decisionId: string;
  subreddit: string;
  targetType: TargetType;
  targetHash: string;
  action: DecisionAction;
  reasonLabel: ReasonLabel;
  timestamp: number;
  source: 'mod_action_trigger' | 'demo_seed' | 'manual_annotation';
  snippet?: string;
};

const REASON_LABELS = [
  { value: 'harassment_abuse', label: 'Harassment / Abuse' },
  { value: 'spam_promotional', label: 'Spam / Promotional' },
  { value: 'low_effort', label: 'Low Effort' },
  { value: 'off_topic', label: 'Off Topic' },
  { value: 'explicit_content', label: 'Explicit Content' },
  { value: 'legal_safety', label: 'Legal / Safety' },
  { value: 'unknown_reason', label: 'Unknown / Unmapped Reason' },
] as const;

type ReasonLabel = (typeof REASON_LABELS)[number]['value'];

const REASON_VALUE_SET = new Set(REASON_LABELS.map((r) => r.value));

const REASON_ALIASES: Record<string, ReasonLabel> = {
  harassment: 'harassment_abuse',
  abuse: 'harassment_abuse',
  harassment_abuse: 'harassment_abuse',
  personal_attack: 'harassment_abuse',
  personal_attacks: 'harassment_abuse',

  spam: 'spam_promotional',
  promotional: 'spam_promotional',
  self_promotion: 'spam_promotional',
  spam_promotional: 'spam_promotional',

  low_effort: 'low_effort',
  loweffort: 'low_effort',
  duplicate: 'low_effort',

  off_topic: 'off_topic',
  offtopic: 'off_topic',
  not_relevant: 'off_topic',

  explicit_content: 'explicit_content',
  explicit: 'explicit_content',
  nsfw: 'explicit_content',

  legal: 'legal_safety',
  legal_safety: 'legal_safety',
  safety: 'legal_safety',
};

function normalizeReasonValue(input: unknown): ReasonLabel | null {
  if (typeof input !== 'string') return null;
  const cleaned = input
    .trim()
    .toLowerCase()
    .replace(/^rule\s*\d+\s*[:\-]\s*/i, '')
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '');

  if (!cleaned) return null;
  if (REASON_VALUE_SET.has(cleaned as ReasonLabel)) return cleaned as ReasonLabel;
  return REASON_ALIASES[cleaned] ?? null;
}

function labelFor(reason: ReasonLabel): string {
  return REASON_LABELS.find((r) => r.value === reason)?.label ?? reason;
}

function idxKey(subreddit: string, targetType: TargetType, reasonLabel: ReasonLabel): string {
  return `idx:reason:${subreddit}:${targetType}:${reasonLabel}`;
}

function decisionKey(decisionId: string): string {
  return `decision:${decisionId}`;
}

function lookupContextKey(token: string): string {
  return `lookupctx:${token}`;
}

function rawLogKey(): string {
  return 'debug:raw-modaction-log';
}

function actorLooksAutomated(actor: string | null): boolean {
  if (!actor) return true;
  const normalized = actor.trim().toLowerCase().replace(/^u\//, '');
  if (!normalized) return true;
  if (normalized === 'automoderator') return true;
  if (APP_ACCOUNT_NAMES.has(normalized)) return true;
  if (normalized.endsWith('bot')) return true;
  return false;
}

function pickFirstString(...values: unknown[]): string | null {
  for (const value of values) {
    if (typeof value === 'string' && value.trim()) return value.trim();
  }
  return null;
}

function extractActor(payload: any): string | null {
  return pickFirstString(
    payload?.moderatorName,
    payload?.moderator?.name,
    payload?.mod?.name,
    payload?.actor?.name,
    payload?.data?.moderatorName,
    payload?.data?.moderator?.name,
    payload?.action?.moderatorName,
    payload?.action?.moderator?.name,
  );
}

function extractSubreddit(payload: any): string {
  return (
    pickFirstString(
      payload?.subredditName,
      payload?.subreddit?.name,
      payload?.subreddit?.displayName,
      payload?.data?.subredditName,
      payload?.action?.subredditName,
      context.subredditName,
    ) ?? 'unknown_subreddit'
  )
    .replace(/^r\//, '')
    .toLowerCase();
}

function extractActionType(payload: any): string | null {
  return pickFirstString(
    payload?.type,
    payload?.action,
    payload?.modAction?.type,
    payload?.data?.type,
    payload?.action?.type,
    payload?.details?.type,
  );
}

function normalizeDecisionAction(payload: any): DecisionAction | null {
  const raw = extractActionType(payload)?.toLowerCase() ?? '';

  // Keep v0 coherent: only human remove/approve on post/comment.
  // Ban/filter/escalate are intentionally excluded because they do not map cleanly
  // to a post/comment precedent lookup.
  if (raw.includes('ban') || raw.includes('filter') || raw.includes('escalat')) return null;
  if (raw.includes('approve')) return 'approved';
  if (raw.includes('remove') || raw.includes('spam')) return 'removed';
  return null;
}

function normalizeTargetType(payload: any): TargetType | null {
  const raw = pickFirstString(
    payload?.target?.type,
    payload?.targetType,
    payload?.thingType,
    payload?.data?.target?.type,
    payload?.data?.targetType,
    payload?.action?.target?.type,
    payload?.action?.targetType,
    extractActionType(payload),
  )?.toLowerCase();

  if (!raw) return null;
  if (raw.includes('comment')) return 'comment';
  if (raw.includes('post') || raw.includes('link')) return 'post';
  return null;
}

function extractTargetId(payload: any): string | null {
  return pickFirstString(
    payload?.target?.id,
    payload?.target?.fullname,
    payload?.targetId,
    payload?.thingId,
    payload?.post?.id,
    payload?.comment?.id,
    payload?.data?.target?.id,
    payload?.data?.targetId,
    payload?.action?.target?.id,
    payload?.action?.targetId,
  );
}

function extractReasonLabel(payload: any): ReasonLabel {
  // Do NOT use free-text description as a key. It fragments the index.
  // Only use controlled/custom reason-like fields; otherwise fall back to unknown_reason.
  const controlledCandidates = [
    payload?.removalReason,
    payload?.removalReason?.title,
    payload?.removalReason?.id,
    payload?.reason,
    payload?.genericReason,
    payload?.details?.reason,
    payload?.details?.removalReason,
    payload?.data?.reason,
    payload?.data?.removalReason,
    payload?.action?.reason,
    payload?.action?.details?.reason,
  ];

  for (const candidate of controlledCandidates) {
    const mapped = normalizeReasonValue(candidate);
    if (mapped) return mapped;
  }
  return 'unknown_reason';
}

function extractTimestamp(payload: any): number {
  const raw = payload?.createdAt ?? payload?.timestamp ?? payload?.data?.createdAt ?? payload?.action?.createdAt;
  if (typeof raw === 'number') return raw > 10_000_000_000 ? raw : raw * 1000;
  if (typeof raw === 'string') {
    const parsed = Date.parse(raw);
    if (!Number.isNaN(parsed)) return parsed;
  }
  return Date.now();
}

function extractModActionId(payload: any): string | null {
  return pickFirstString(payload?.id, payload?.modActionId, payload?.data?.id, payload?.action?.id);
}

function extractSnippet(payload: any): string | undefined {
  const text = pickFirstString(
    payload?.target?.body,
    payload?.target?.title,
    payload?.post?.title,
    payload?.comment?.body,
    payload?.data?.target?.body,
    payload?.data?.target?.title,
  );
  if (!text) return undefined;
  return text.replace(/\s+/g, ' ').trim().slice(0, 120);
}

function stableHash(input: string): string {
  // Pure-TS fallback because crypto.subtle / crypto.randomUUID availability can vary by sandbox.
  // This is fine for demo dedup. For privacy-critical production, replace with a real salted SHA-256
  // supported by your verified Devvit runtime.
  let h = 0x811c9dc5;
  const salted = `modcase-v0:${input}`;
  for (let i = 0; i < salted.length; i += 1) {
    h ^= salted.charCodeAt(i);
    h = Math.imul(h, 0x01000193);
  }
  return (h >>> 0).toString(16).padStart(8, '0');
}

function makeId(prefix = 'id'): string {
  return `${prefix}:${Date.now()}:${Math.random().toString(36).slice(2, 10)}`;
}

function buildDecisionFromModAction(payload: any): DecisionRecord | null {
  const actor = extractActor(payload);
  if (actorLooksAutomated(actor)) return null;

  const action = normalizeDecisionAction(payload);
  const targetType = normalizeTargetType(payload);
  const targetId = extractTargetId(payload);
  if (!action || !targetType || !targetId) return null;

  const subreddit = extractSubreddit(payload);
  const reasonLabel = extractReasonLabel(payload);
  const modActionId = extractModActionId(payload);
  const timestamp = extractTimestamp(payload);

  // Use ModAction id when present so retries are idempotent. Fallback is deterministic enough for v0.
  const decisionId = modActionId ? `modaction:${modActionId}` : `fallback:${stableHash(`${subreddit}:${targetType}:${targetId}:${action}:${reasonLabel}:${timestamp}`)}`;

  return {
    decisionId,
    subreddit,
    targetType,
    targetHash: stableHash(`${subreddit}:${targetType}:${targetId}`),
    action,
    reasonLabel,
    timestamp,
    source: 'mod_action_trigger',
    snippet: extractSnippet(payload),
  };
}

async function saveDecision(record: DecisionRecord): Promise<void> {
  await redis.set(decisionKey(record.decisionId), JSON.stringify(record));
  await redis.zAdd(idxKey(record.subreddit, record.targetType, record.reasonLabel), {
    member: record.decisionId,
    score: record.timestamp,
  });
}

async function recentDecisionIds(
  subreddit: string,
  targetType: TargetType,
  reasonLabel: ReasonLabel,
  limit = LOOKUP_LIMIT,
): Promise<string[]> {
  const key = idxKey(subreddit, targetType, reasonLabel);
  const count = await redis.zCard(key);
  if (!count || count <= 0) return [];

  const start = Math.max(0, count - limit);
  const stop = Math.max(0, count - 1);

  const items = await redis.zRange(key, start, stop, { by: 'rank' });
  const ids = items.map((item: any) => String(item.member));

  // zRange by rank returns ascending score in the docs. Reverse to newest-first.
  // Verify this in playtest once; if the order differs, remove this reverse.
  return ids.reverse();
}

async function loadDecisionRecords(ids: string[]): Promise<DecisionRecord[]> {
  if (!ids.length) return [];
  const values = await redis.mGet(ids.map(decisionKey));
  return values
    .map((raw) => {
      if (!raw) return null;
      try {
        return JSON.parse(raw) as DecisionRecord;
      } catch {
        return null;
      }
    })
    .filter(Boolean) as DecisionRecord[];
}

function summarize(records: DecisionRecord[]): {
  total: number;
  removed: number;
  approved: number;
  signal: SignalKind;
  majorityAction?: DecisionAction;
  majorityPct?: number;
} {
  const removed = records.filter((r) => r.action === 'removed').length;
  const approved = records.filter((r) => r.action === 'approved').length;
  const total = removed + approved;

  if (total < MIN_SIGNAL_SAMPLE) return { total, removed, approved, signal: 'limited_history' };

  const majorityAction: DecisionAction = removed >= approved ? 'removed' : 'approved';
  const majorityCount = Math.max(removed, approved);
  const majorityPct = majorityCount / total;

  if (majorityPct >= 0.8) return { total, removed, approved, signal: 'settled', majorityAction, majorityPct };
  if (majorityPct >= 0.6) return { total, removed, approved, signal: 'leaning', majorityAction, majorityPct };
  return { total, removed, approved, signal: 'contested', majorityAction, majorityPct };
}

function formatSignal(summary: ReturnType<typeof summarize>): string {
  if (summary.signal === 'limited_history') {
    return `Limited history: ${summary.total} matching decision${summary.total === 1 ? '' : 's'} so far. Show counts, but do not infer a norm yet.`;
  }
  if (summary.signal === 'settled') {
    return `Settled team pattern: ${Math.round((summary.majorityPct ?? 0) * 100)}% ${summary.majorityAction}.`;
  }
  if (summary.signal === 'leaning') {
    return `Leaning pattern: ${Math.round((summary.majorityPct ?? 0) * 100)}% ${summary.majorityAction}, but not fully settled.`;
  }
  return `Contested rule: the team is split on this reason.`;
}

function formatPrecedentSummary(reasonLabel: ReasonLabel, targetType: TargetType, records: DecisionRecord[]): string {
  const s = summarize(records);
  const examples = records.slice(0, DISPLAY_LIMIT).map((r, i) => {
    const age = new Date(r.timestamp).toLocaleDateString('en-US');
    const snippet = r.snippet ? ` — “${r.snippet}”` : '';
    return `${i + 1}. ${r.action} ${r.targetType} — ${age}${snippet}`;
  });

  return [
    `ModCase precedent`,
    `Reason: ${labelFor(reasonLabel)}`,
    `Content type: ${targetType}`,
    ``,
    `Counts from last ${LOOKUP_LIMIT} matching decisions:`,
    `Removed: ${s.removed}`,
    `Approved: ${s.approved}`,
    `Total: ${s.total}`,
    ``,
    formatSignal(s),
    ``,
    examples.length ? `Recent examples:\n${examples.join('\n')}` : 'No prior examples yet. Use the demo seeder or let automatic capture build history.',
  ].join('\n');
}

function targetContextFromMenu(input: any): { targetType: TargetType; targetId: string; subreddit: string } | null {
  const targetId = pickFirstString(input?.postId, input?.commentId, input?.targetId, input?.thingId, input?.post?.id, input?.comment?.id);
  if (!targetId) return null;

  const raw = pickFirstString(input?.location, input?.targetType, input?.thingType, input?.postId ? 'post' : null, input?.commentId ? 'comment' : null)?.toLowerCase();
  const targetType: TargetType | null = raw?.includes('comment') ? 'comment' : raw?.includes('post') ? 'post' : null;
  if (!targetType) return null;

  return {
    targetType,
    targetId,
    subreddit: extractSubreddit(input),
  };
}

app.get('/api/health', (c) => c.json({ ok: true, app: 'modcase' }));

app.post('/internal/triggers/on-mod-action', async (c) => {
  const input = await c.req.json<any>();
  console.log('[ModCase] raw onModAction payload:', JSON.stringify(input, null, 2));

  if (CAPTURE_RAW_PAYLOADS_FOR_DEBUG) {
    const logId = makeId('rawlog');
    await redis.set(`debug:raw:${logId}`, JSON.stringify(input));
    await redis.zAdd(rawLogKey(), { member: logId, score: Date.now() });
  }

  const record = buildDecisionFromModAction(input);
  if (!record) {
    console.log('[ModCase] skipped mod action after normalization/filtering');
    return c.json<TriggerResponse>({ status: 'ok' });
  }

  await saveDecision(record);
  console.log('[ModCase] captured decision:', JSON.stringify(record, null, 2));
  return c.json<TriggerResponse>({ status: 'ok' });
});

app.post('/internal/menu/check-precedent', async (c) => {
  const input = await c.req.json<MenuItemRequest & Record<string, any>>();
  const target = targetContextFromMenu(input);
  if (!target) {
    return c.json<UiResponse>({ showToast: 'ModCase could not identify the post/comment context. Check the menu payload logs.' });
  }

  const token = makeId('lookup');
  await redis.set(lookupContextKey(token), JSON.stringify(target), { expiration: LOOKUP_CONTEXT_TTL_SECONDS } as any);

  return c.json<UiResponse>({
    showForm: {
      name: 'modcaseReasonPicker',
      form: {
        title: 'Check ModCase precedent',
        description: 'Pick the rule/reason you are considering. ModCase will show how the team handled similar past decisions.',
        acceptLabel: 'Show precedent',
        cancelLabel: 'Cancel',
        fields: [
          {
            type: 'select',
            name: 'reasonLabel',
            label: 'Reason / rule',
            required: true,
            options: REASON_LABELS.map((r) => ({ label: r.label, value: r.value })),
            defaultValue: ['harassment_abuse'],
          },
        ],
      },
      data: { lookupToken: token },
    },
  });
});

type ReasonPickerForm = {
  lookupToken?: string;
  reasonLabel?: string | string[];
};

app.post('/internal/form/reason-picker-submit', async (c) => {
  const body = await c.req.json<ReasonPickerForm>();
  const token = body.lookupToken;
  const rawReason = Array.isArray(body.reasonLabel) ? body.reasonLabel[0] : body.reasonLabel;
  const reasonLabel = normalizeReasonValue(rawReason) ?? 'unknown_reason';

  if (!token) return c.json<UiResponse>({ showToast: 'ModCase lookup context expired. Re-open the menu action.' });

  const rawContext = await redis.get(lookupContextKey(token));
  if (!rawContext) return c.json<UiResponse>({ showToast: 'ModCase lookup context expired. Re-open the menu action.' });

  const lookup = JSON.parse(rawContext) as { subreddit: string; targetType: TargetType; targetId: string };
  const ids = await recentDecisionIds(lookup.subreddit, lookup.targetType, reasonLabel, LOOKUP_LIMIT);
  const records = await loadDecisionRecords(ids);
  const summaryText = formatPrecedentSummary(reasonLabel, lookup.targetType, records);

  return c.json<UiResponse>({
    showForm: {
      name: 'modcaseSummaryAck',
      form: {
        title: 'ModCase precedent',
        acceptLabel: 'Close',
        fields: [
          {
            type: 'paragraph',
            name: 'summary',
            label: 'Team precedent',
            defaultValue: summaryText,
            disabled: true,
            lineHeight: 14,
          },
        ],
      },
      data: { summary: summaryText },
    },
  });
});

app.post('/internal/form/summary-ack', async (c) => {
  await c.req.json().catch(() => ({}));
  return c.json<UiResponse>({ status: 'ok' });
});

app.post('/internal/menu/seed-demo', async (c) => {
  const input = await c.req.json<MenuItemRequest & Record<string, any>>();
  const subreddit = extractSubreddit(input);
  const now = Date.now();

  const seedRecords: DecisionRecord[] = [
    ['harassment_abuse', 'comment', 'removed', 'Personal attack against another user.'],
    ['harassment_abuse', 'comment', 'removed', 'Insult-heavy reply in a heated thread.'],
    ['harassment_abuse', 'comment', 'removed', 'Direct abuse with no substantive argument.'],
    ['harassment_abuse', 'comment', 'removed', 'Hostile comment targeting a person.'],
    ['harassment_abuse', 'comment', 'approved', 'Sharp disagreement, but not personal abuse.'],
    ['harassment_abuse', 'comment', 'removed', 'Repeated name-calling.'],
    ['harassment_abuse', 'comment', 'removed', 'Threatening or intimidating language.'],
    ['harassment_abuse', 'comment', 'approved', 'Borderline but within heated discussion norms.'],
    ['low_effort', 'post', 'removed', 'Title-only post with no context.'],
    ['low_effort', 'post', 'removed', 'Duplicate/basic question already answered.'],
    ['off_topic', 'post', 'removed', 'Unrelated to the community focus.'],
    ['spam_promotional', 'post', 'removed', 'Promotional link with no community value.'],
  ].map(([reasonLabel, targetType, action, snippet], i) => ({
    decisionId: `${DEMO_SEED_PREFIX}:${subreddit}:${i}`,
    subreddit,
    targetType: targetType as TargetType,
    targetHash: stableHash(`${subreddit}:${targetType}:demo-${i}`),
    action: action as DecisionAction,
    reasonLabel: reasonLabel as ReasonLabel,
    timestamp: now - (i + 1) * 86_400_000,
    source: 'demo_seed',
    snippet: snippet as string,
  }));

  for (const record of seedRecords) await saveDecision(record);
  return c.json<UiResponse>({ showToast: `Seeded ${seedRecords.length} ModCase demo decisions for r/${subreddit}.` });
});

app.post('/internal/menu/show-debug-log-count', async (c) => {
  await c.req.json<MenuItemRequest>().catch(() => ({}));
  const count = await redis.zCard(rawLogKey());
  return c.json<UiResponse>({ showToast: `ModCase raw onModAction payloads logged: ${count}. Check Devvit logs for full payloads.` });
});

export default createServer(app);
